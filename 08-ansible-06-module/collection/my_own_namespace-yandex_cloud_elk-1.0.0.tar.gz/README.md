# my_own_collection
The collection contains the role that runs the module.
The module writes (creates) text to a file.
